# 2739번 구구단

N = int(input())
for n in range(1, 10):
    print(f'{N} * {n} = {N * n}')