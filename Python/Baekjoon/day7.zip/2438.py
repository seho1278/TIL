# 2438번 별 찍기 - 1
N = int(input())
result = 0
for n in range(N):
    result += 1
    print('*'*result)
